function OnLoad () {

}
function CheckInput () {
	var pattern = /^[0-9]{10,11}$/;
	var patternEmail1 = /^([a-zA-Z0-9_\.\-])+\@gmail\.com/;
	var patternEmail2 = /^([a-zA-Z0-9_\.\-])+\@gm\.uit\.edu\.vn/;
	var maso = document.getElementById("maso");
	var hoten = document.getElementById("hoten");
	var diachi = document.getElementById("diachi");
	var sdt = document.getElementById("sdt");
	var gioitinhnam = document.getElementById("gioitinhnam");
	var gioitinhnu = document.getElementById("gioitinhnu");
	var ngay = document.getElementById("ngay");
	var thang = document.getElementById("thang");
	var nam = document.getElementById("nam");
	var email = document.getElementById("email");
	if(maso.value.trim() == ""){
		alert("Mã số không được để trống!");
		maso.focus();
		return;
	}
	if(hoten.value.trim() == ""){
		alert("Họ tên không được để trống!");
		hoten.focus();
		return;
	}
	if(diachi.value.trim() == ""){
		alert("Địa chỉ không được để trống!");
		diachi.focus();
		return;
	}
	if(!sdt.value.trim().match(pattern)){
		alert("Số điện thoại phải là số và có độ dài từ 10 - 11 số!");
		sdt.focus();
		return;
	}
	if(gioitinhnam.checked == false && gioitinhnu.checked == false){
		alert("Vui lòng chọn giới tính");
		gioitinhnam.focus();
		return;
	}
	if(ngay.value.trim() != "" || nam.value.trim() != ""){
		if(checkDate(ngay.value, thang.value, nam.value) == false){
		alert("Ngày tháng năm nhập vào không hợp lệ, vui lòng nhập lại!");
		ngay.focus();
		return;
		}
	}
	if(email.value.match(patternEmail1) == false && email.value.match(patternEmail2) == false){
		alert("Email phải là gmail (gmail.com / gm.uit.edu.vn), vui lòng nhập lại!");
		email.focus();
		return;
	}
	
}

function checkDate (date, month, year) {
	var d = parseInt(date);
	var m = parseInt(month);
	var y = parseInt(year);
	var da = new Date(y, m - 1, d);
	if(da.getFullYear() == y && (da.getMonth() + 1) == m && da.getDate() == d)
		return true;
	return false;
}

function toRight () {
	var x = document.getElementById("list-left");
	x.remove(x.selectedIndex);
}